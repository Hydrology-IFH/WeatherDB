# secret settings for weatherDB module

DB_HOST = "" # fill in the host
DB_PORT = 5432
DB_WEA_NAME = "weather"
DB_WEA_USER = "" # fill in the user
DB_WEA_PWD = "" #fill in the password
